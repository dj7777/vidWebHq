================================================================================
Kernel Team FLV Video Player v5.5 released on January 21 2016
================================================================================

Installation [en]:

1) Unpack archive into /%DOMAIN_ROOT%/kt_player folder. If you want to install
player into a different folder, make sure you update player .htaccess file with
your new value.

2) In /%DOMAIN_ROOT%/kt_player/.htaccess file change %DOMAIN% token with your
domain name.

3) Copy demo/crossdomain.xml file into your domain root folder. If you are going
to use images or videos from other domains (and subdomains), you should copy
this file to every such domain (subdomain).

Documentation is available in player archive. Player support is provided via
http://kernel-video-sharing.com/support/

Enjoy!

================================================================================

Установка [ru]:

1) Распакуйте архив с файлами плеера в директорию /%DOMAIN_ROOT%/kt_player. Если
вы хотите установить плеер в другую директорию, убедитесь, что вы заменили
директорию в .htaccess файле плеера.

2) В файле /%DOMAIN_ROOT%/kt_player/.htaccess замените токен %DOMAIN% на
название вашего домена.

3) Скопируйте файл demo/crossdomain.xml в корень вашего домена. Если вы
планируете использовать видео или изображения, которые хостятся на других доменах
(и сабдоменах), вам необходимо скопировать этот файл на все другие домены
(сабдомены), с которых плеер будет что-то использовать.

Документация находится в архиве плеера. Поддержка осуществляется по адресу
http://kernel-video-sharing.com/support/

Надеемся, вам понравится наш плеер!