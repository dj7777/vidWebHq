# ServerMonitor
PHP Script to show the server status Memory, CPU and Disk usage in real time

This script was maded for linux only.

Just download the script, put it in your apache folder and enjou the show.

Also pretty easy to use it with another applications, just call the *.json.php files to get the usage of your server.  

Check out our the <a href="http://monitor.youphptube.com/">demo page</a>
