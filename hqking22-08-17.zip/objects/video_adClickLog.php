<?php
header('Content-Type: application/json');
if(empty($global['systemRootPath'])){
    $global['systemRootPath'] = "../";
}
require_once $global['systemRootPath'].'videos/configuration.php';
require_once $global['systemRootPath'] . 'objects/user.php';
require 'video_ad.php';
Video_ad::clickLog($_GET['video_ads_logs_id']);
Video_ad::redirect($_GET['adId']);